package com.example.taskmanager;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import java.util.ArrayList;

public class Adaptertodo extends ArrayAdapter implements View.OnClickListener {
    private Activity context;
    private ArrayList<String> todotasks;

    public Adaptertodo(Context context, ArrayList<String> todotasks ){
        super(context,R.layout.todo,todotasks);
        this.context=(Activity) context;
        this.todotasks=todotasks;
    }

    public View getView(int position,View convertView, ViewGroup parent ){
        if(convertView==null){
            LayoutInflater inflater=context.getLayoutInflater();
            convertView=inflater.inflate(R.layout.todo,null);
        }

        TextView task = convertView.findViewById(R.id.todotext);
        ImageButton confirm = convertView.findViewById(R.id.confirm);
        ImageButton delete = convertView.findViewById(R.id.delete);

        confirm.setTag(position);
        delete.setTag(position);

        task.setText(todotasks.get(position));

        return convertView;
    }
    public void onClick(View v){

    }
}
