package com.example.taskmanager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import java.text.SimpleDateFormat;
import java.util.Date;
import android.database.Cursor;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.*;
import android.widget.*;
import java.util.ArrayList;

public class TaskManager extends AppCompatActivity {
    public ArrayList<String> todotasks;
    public ArrayList<String> completedtaskes;
    private ArrayAdapter adapter1, adapter2;
    int total = 0;
    int completed = 0;
    ListView tasksView;
    ListView completedView;
    EditText tasktoadd;
    ImageView plume;
    TextView taskconfirmed;
    ImageView valid;
    TextView t;
    ImageButton addbleu;
    ImageView s;
    ImageButton confirmtask;
    ImageButton canceltask;
    private Switch aSwitch;
    DBHelper DB;
    String datecal;
    TextView datedujour;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        if (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES) {
            setTheme(R.style.DarkTheme_TaskManager);
        } else {
            setTheme(R.style.Theme_TaskManager);
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_manager);

        datedujour = findViewById(R.id.datedujour);
        aSwitch = findViewById(R.id.switche);
        TextView tasks = findViewById(R.id.tasks);
        tasksView = findViewById(R.id.todotasks);
        completedView = findViewById(R.id.completedtasks);
        valid = findViewById(R.id.ichara);
        taskconfirmed = findViewById(R.id.completed);
        t = findViewById(R.id.progress);
        tasktoadd = findViewById(R.id.taskname);
        plume = findViewById(R.id.plume);
        confirmtask = findViewById(R.id.confirmtask);
        canceltask = findViewById(R.id.canceltask);
        s = findViewById(R.id.s);
        tasks = findViewById(R.id.tasks);
        t = findViewById(R.id.progress);

        SimpleDateFormat formatter = new SimpleDateFormat("dd/M/yyyy");
        Date date = new Date();
        datecal = formatter.format(date);
        datedujour.setText(datecal);

        todotasks = new ArrayList<String>();
        adapter1 = new Adaptertodo(this, todotasks);
        tasksView.setAdapter(adapter1);
        completedtaskes = new ArrayList<String>();
        adapter2 = new Adaptercompleted(this, completedtaskes);
        completedView.setAdapter(adapter2);
        todotasks.removeAll(todotasks);
        completedtaskes.removeAll(completedtaskes);
        adapter1.notifyDataSetChanged();
        adapter2.notifyDataSetChanged();

        // tasks loading
        DB = new DBHelper(this);
        Cursor res = DB.getdata(datecal);
        while (res.moveToNext()) {
            total += 1;
            int taskres = res.getInt(2);
            if (taskres == 0) {
                todotasks.add(res.getString(0));
            } else {
                completed += 1;
                completedtaskes.add(res.getString(0));
            }
        }
        adapter1.notifyDataSetChanged();
        adapter2.notifyDataSetChanged();
        t.setText(completed + " On " + total + " Completed Today");

        if (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES) {
            aSwitch.setChecked(true);
        }
        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                    reset();
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                    reset();
                }
            }
        });

        valid.setVisibility(View.GONE);
        taskconfirmed.setVisibility(View.GONE);
        confirmtask.setVisibility(View.GONE);
        canceltask.setVisibility(View.GONE);
        tasktoadd.setVisibility(View.GONE);
        plume.setVisibility(View.GONE);
    }

    private void reset() {
            Intent intent = new Intent(getApplicationContext(), TaskManager.class);
            startActivity(intent);
            finish();}

    public void fcbleu(View view) {
            tasktoadd = findViewById(R.id.taskname);
            addbleu = findViewById(R.id.addbleu);
            plume = findViewById(R.id.plume);

            tasktoadd.setVisibility(View.VISIBLE);
            plume.setVisibility(View.VISIBLE);
            addbleu.setVisibility(View.GONE);
            confirmtask.setVisibility(View.VISIBLE);
            canceltask.setVisibility(View.VISIBLE);}

    public void confirmtask(View view) {

            if (tasktoadd.getText().length() != 0) {
                tasktoadd = findViewById(R.id.taskname);
                plume = findViewById(R.id.plume);
                addbleu = findViewById(R.id.addbleu);
                confirmtask = findViewById(R.id.confirmtask);
                canceltask = findViewById(R.id.canceltask);
                ImageView s = findViewById(R.id.s);
                TextView tasks = findViewById(R.id.tasks);
                t = findViewById(R.id.progress);

                todotasks.add(tasktoadd.getText().toString());
                DB.inserttask(tasktoadd.getText().toString(),datedujour.getText().toString(),0);
                tasktoadd.setText("");
                adapter1.notifyDataSetChanged();
                adapter2.notifyDataSetChanged();
                total += 1;

                t.setText(completed + " On " + total + " Completed Today");

                valid.setVisibility(View.VISIBLE);
                taskconfirmed.setVisibility(View.VISIBLE);
                t.setVisibility(View.VISIBLE);
                tasktoadd.setVisibility(View.GONE);
                plume.setVisibility(View.GONE);
                addbleu.setVisibility(View.VISIBLE);
                confirmtask.setVisibility(View.GONE);
                canceltask.setVisibility(View.GONE);
                s.setVisibility(View.VISIBLE);
                tasks.setVisibility(View.VISIBLE);

                Toast toast=Toast.makeText(getApplicationContext(),"Task Added Successfully",Toast.LENGTH_SHORT);
                toast.show();}}

    public void canceltask(View view){

            tasktoadd = findViewById(R.id.taskname);
            plume = findViewById(R.id.plume);
            addbleu = findViewById(R.id.addbleu);
            confirmtask = findViewById(R.id.confirmtask);
            canceltask = findViewById(R.id.canceltask);

            tasktoadd.setText("");

            tasktoadd.setVisibility(View.GONE);
            plume.setVisibility(View.GONE);
            addbleu.setVisibility(View.VISIBLE);
            confirmtask.setVisibility(View.GONE);
            canceltask.setVisibility(View.GONE);

            adapter1.notifyDataSetChanged();}

        public void confirm(View view) {

            int position = (Integer) view.getTag();
            completedtaskes.add(todotasks.get(position));
            DB.updatetask(todotasks.get(position),datedujour.getText().toString(),1);
            todotasks.remove(position);
            adapter1.notifyDataSetChanged();
            adapter2.notifyDataSetChanged();
            completed += 1;
            t.setText(completed + " On " + total + " Completed Today");

            valid.setVisibility(View.VISIBLE);
            taskconfirmed.setVisibility(View.VISIBLE);
            t.setVisibility(View.VISIBLE);}

    public void delete(View view) {
            int position = (Integer) view.getTag();
            String task = todotasks.get(position);
            DB.deletetask(task);
            todotasks.remove(position);
            total -= 1;
            adapter1.notifyDataSetChanged();

            if (total>0) {
                t.setText(completed + " On " + total + " Completed Today");}

            else{
                ImageView s = findViewById(R.id.s);
                TextView tasks = findViewById(R.id.tasks);
                valid.setVisibility(View.GONE);
                taskconfirmed.setVisibility(View.GONE);
                t.setVisibility(View.GONE);
                s.setVisibility(View.GONE);
                tasks.setVisibility(View.GONE);}

            Toast toast=Toast.makeText(getApplicationContext(),"Task Removed Successfully",Toast.LENGTH_SHORT);
            toast.show();}

    public void pagecalendar(View view){
            Intent intent = new Intent(this, Calendarpage.class);
            this.startActivity(intent);}

    public void pagestats(View view){
            Intent intent = new Intent(this, Stats.class);
            this.startActivity(intent);}}
