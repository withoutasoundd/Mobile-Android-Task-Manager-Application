package com.example.taskmanager;

public class Calendrier {

    private String taskname;
    public Calendrier(String taskname){
        this.taskname=taskname;
    }
    public void Settaskname(String taskname){
        this.taskname=taskname;
    }
    public String getTaskname(){
        return taskname;
    }}
