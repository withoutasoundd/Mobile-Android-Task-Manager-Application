package com.example.taskmanager;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import java.util.ArrayList;
public class Adaptercompleted extends ArrayAdapter implements View.OnClickListener {
    private Activity context;
    private ArrayList<String> completedd;

    public Adaptercompleted(Context context, ArrayList<String> completedd ){
        super(context,R.layout.completed,completedd);
        this.context=(Activity) context;
        this.completedd=completedd;
    }

    public View getView(int position,View convertView, ViewGroup parent ){
        if(convertView==null){
            LayoutInflater inflater=context.getLayoutInflater();
            convertView=inflater.inflate(R.layout.completed,null);
        }
        TextView completed = convertView.findViewById(R.id.completede);

        completed.setText(completedd.get(position));

        return convertView;
    }
    public void onClick(View v){

    }
}
