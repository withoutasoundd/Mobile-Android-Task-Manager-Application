package com.example.taskmanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import java.text.SimpleDateFormat;
import java.util.Date;
import android.database.Cursor;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Calendarpage extends AppCompatActivity {
    EditText tasktoadd;
    ImageView plume;
    ImageButton addbleu;
    ImageButton confirmtask;
    ImageButton canceltask;
    public ArrayList<Calendrier> todotasks;
    ArrayAdapter adapter;
    ListView tasksView;
    TextView datecliquee;
    String datecal;
    CalendarView calendar;
    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

            if (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES) {
                setTheme(R.style.DarkTheme_TaskManager);
            } else {
                setTheme(R.style.Theme_TaskManager);}

            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_calendarpage);

            datecliquee = findViewById(R.id.date);
            tasksView = findViewById(R.id.listView);
            calendar = (CalendarView) findViewById(R.id.calendarView);
            tasktoadd = findViewById(R.id.taskname);
            confirmtask = findViewById(R.id.confirmtask);
            canceltask = findViewById(R.id.canceltask);
            plume = findViewById(R.id.plume);

            DB = new DBHelper(this);
            todotasks = new ArrayList<Calendrier>();
            adapter = new Adaptercalendrier(this, todotasks);
            tasksView.setAdapter(adapter);
            SimpleDateFormat formatter = new SimpleDateFormat("dd/M/yyyy");
            Date date = new Date();
            datecliquee.setText(formatter.format(date));
            todotasks.removeAll(todotasks);

            Cursor res1 = DB.getdata(datecliquee.getText().toString());
            while(res1.moveToNext()){
                int taskres = res1.getInt(2);
                if (taskres==0){
                    todotasks.add(new Calendrier(res1.getString(0)+ " : Not completed"));}
                else{todotasks.add(new Calendrier(res1.getString(0)+ " : Completed"));}}

            adapter.notifyDataSetChanged();
            calendar.setOnDateChangeListener((view, y, mm, d) -> {
                datecal = d + "/" + (mm + 1) + "/" + y;
                datecliquee.setText(datecal);
                todotasks.removeAll(todotasks);
                adapter.notifyDataSetChanged();
                Cursor res = DB.getdata(datecal);
                while(res.moveToNext()){
                    todotasks.add(new Calendrier(res.getString(0)));}
                adapter.notifyDataSetChanged();});

            confirmtask.setVisibility(View.GONE);
            canceltask.setVisibility(View.GONE);
            tasktoadd.setVisibility(View.GONE);
            plume.setVisibility(View.GONE);}

    public void fcbleu(View view) {

            tasktoadd = findViewById(R.id.taskname);
            addbleu = findViewById(R.id.addbleu);
            plume = findViewById(R.id.plume);

            tasktoadd.setVisibility(View.VISIBLE);
            plume.setVisibility(View.VISIBLE);
            addbleu.setVisibility(View.GONE);
            confirmtask.setVisibility(View.VISIBLE);
            canceltask.setVisibility(View.VISIBLE);}

    public void confirmtask(View view) {

            tasktoadd = findViewById(R.id.taskname);
            plume = findViewById(R.id.plume);
            addbleu = findViewById(R.id.addbleu);
            confirmtask = findViewById(R.id.confirmtask);
            canceltask = findViewById(R.id.canceltask);
            datecliquee = findViewById(R.id.date);

            DB.inserttask(tasktoadd.getText().toString(),datecliquee.getText().toString(),0);
            todotasks.add(new Calendrier(tasktoadd.getText().toString()+" : Not Completed"));
            adapter.notifyDataSetChanged();
            Toast toast = Toast.makeText(getApplicationContext(), "Task Added Successfully", Toast.LENGTH_SHORT);
            toast.show();
            tasktoadd.setText("");

            tasktoadd.setVisibility(View.GONE);
            plume.setVisibility(View.GONE);
            addbleu.setVisibility(View.VISIBLE);
            confirmtask.setVisibility(View.GONE);
            canceltask.setVisibility(View.GONE);}

    public void canceltask(View view) {

            tasktoadd = findViewById(R.id.taskname);
            plume = findViewById(R.id.plume);
            addbleu = findViewById(R.id.addbleu);
            confirmtask = findViewById(R.id.confirmtask);
            canceltask = findViewById(R.id.canceltask);

            tasktoadd.setText("");

            tasktoadd.setVisibility(View.GONE);
            plume.setVisibility(View.GONE);
            addbleu.setVisibility(View.VISIBLE);
            confirmtask.setVisibility(View.GONE);
            canceltask.setVisibility(View.GONE);}

    public void delete(View view) {
            int position = (Integer) view.getTag();
            String task = todotasks.get(position).getTaskname();
            DB.deletetask(task);
            todotasks.remove(position);
            adapter.notifyDataSetChanged();
            Toast toast = Toast.makeText(getApplicationContext(), "Task Removed Successfully", Toast.LENGTH_SHORT);
            toast.show();}

    public void pagetasks (View view){
            Intent intent = new Intent(this, TaskManager.class);
            this.startActivity(intent);}

    public void pagestats (View view){
        Intent intent = new Intent(this, Stats.class);
        this.startActivity(intent);}}
