package com.example.taskmanager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Stats extends AppCompatActivity {
    TextView pourcentage;
    TextView rating;
    double conf;
    double nonconf;
    double perc;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES) {
            setTheme(R.style.DarkTheme_TaskManager);
        } else {
            setTheme(R.style.Theme_TaskManager);
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);
        pourcentage = findViewById(R.id.pourcentage);
        rating = findViewById(R.id.rating);

        DB = new DBHelper(this);
        conf = DB.getnbtasks(1).getCount();
        nonconf = DB.getnbtasks(0).getCount();
        perc = (conf/(conf+nonconf))*100;
        pourcentage.setText("You accomplished "+(int) perc+" % of all your tasks");

        if (perc<30.0){
            rating.setText("Rating : Low Productivity");
        }
        if ((perc>30.0)&(perc<65)){
            rating.setText("Rating : Average Productivity");
        }
        if (perc>65) {
            rating.setText("Rating : High Productivity");}}

    public void pagecalendar (View view){
        Intent intent = new Intent(this, Calendarpage.class);
        this.startActivity(intent);
    }
    public void pagetasks (View view){
        Intent intent = new Intent(this, TaskManager.class);
        this.startActivity(intent);
    }
}