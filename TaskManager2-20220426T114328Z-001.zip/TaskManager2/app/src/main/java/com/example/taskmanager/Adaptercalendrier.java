package com.example.taskmanager;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import java.util.ArrayList;
public class Adaptercalendrier extends ArrayAdapter implements View.OnClickListener {
    private Activity context;
    public ArrayList<Calendrier> todotasks;

    public Adaptercalendrier(Context context, ArrayList<Calendrier> todotasks) {
        super(context, R.layout.calendartasks, todotasks);
        this.context = (Activity) context;
        this.todotasks = todotasks;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = context.getLayoutInflater();
            convertView = inflater.inflate(R.layout.calendartasks, null);
        }

        TextView task = convertView.findViewById(R.id.todotext);
        ImageButton delete = convertView.findViewById(R.id.remove);
        delete.setTag(position);

        task.setText(todotasks.get(position).getTaskname());

        return convertView;
    }

    @Override
    public void onClick(View v) {

    }
}
