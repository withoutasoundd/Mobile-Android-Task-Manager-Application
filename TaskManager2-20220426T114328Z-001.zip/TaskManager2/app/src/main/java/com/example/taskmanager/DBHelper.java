package com.example.taskmanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context) {
        super(context, "Userdata.db", null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create table tasks(task TEXT primary key,Date TEXT, status INTEGER )");}

    @Override
    public void onUpgrade(SQLiteDatabase DB, int oldVersion, int newVersion) {
        DB.execSQL("drop table if exists tasks");}

    // 0 pour non confirmed et 1 pour confirmed
    public Boolean inserttask(String task, String Date, int status){

        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Date", Date);
        contentValues.put("task", task);
        contentValues.put("status", status);
        long result =DB.insert("tasks", null, contentValues);

        if(result==-1){
            return false;
        }
        else{
            return true;
        }
    }
    public Boolean updatetask(String task, String Date, int status) {

        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Date", Date);
        contentValues.put("task", task);
        contentValues.put("status", status);
        Cursor cursor = DB.rawQuery("Select * from tasks where task =?", new String[]{task});

        if (cursor.getCount() > 0) {
            long result = DB.update("tasks", contentValues, "task=?", new String[]{task});
            if (result == -1) {
                return false;
            } else {
                return true;}}
        else {
            return false;}}

        public Boolean deletetask(String task) {

        SQLiteDatabase DB = this.getWritableDatabase();
            Cursor cursor = DB.rawQuery("Select * from tasks where task =?", new String[]{task});
            if (cursor.getCount() > 0) {
                long result = DB.delete("tasks", "task=?", new String[]{task});
                if (result == -1) {
                    return false;}
                else {
                    return true;}}
            else {
                return false;}}

    public Cursor getdata(String Date) {

        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from tasks where Date =?",new String[]{Date});
        return cursor; }

    public Cursor getnbtasks(int status) {

        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from tasks where status =?",new String[]{String.valueOf(status)});
        return cursor;}}
